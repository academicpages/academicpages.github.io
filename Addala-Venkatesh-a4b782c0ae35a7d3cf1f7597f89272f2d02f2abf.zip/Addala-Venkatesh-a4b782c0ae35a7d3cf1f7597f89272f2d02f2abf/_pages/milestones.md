---
layout: archive
permalink: /milestones/
title: ""
author_profile: true
---

## 🏆 🌌 **Achievements Across the Stars**

- **Prathibha Merit Award (2017)**: Honored by the Chief Minister of Andhra Pradesh for exemplary academic achievement.
- **Gold Medal for Valedictorian Honors (2018)**: Awarded by the College Chairman for achieving the highest rank in the Diploma program at Sree Vidyanikethan Engineering College.
- **Technical Excellence Award (2021)**: Honored for exceptional contributions and performance at Exafluence.
- **MongoDB Certified Developer (2021)**: Demonstrated proficiency in MongoDB development and advanced data management.
- **Databricks Certified Developer (2023)**: Certified expertise in data engineering with Databricks, focusing on scalable data solutions.

