Teaching
======
* Instructor of Records, Florida State University, Department of Geography, 2016 ongoing Courses:
  * Teaching Assistant, GIS Lab Spring, 2016
  * Instructor of Record, Computer Cartography Summer, 2016
  * Teaching Assistant, GIS Lab Fall, 2016
  * Teaching Assistant, GIS Lab Spring, 2017
  * Instructor of Record, Introduction to GIS Summer, 2017
  * Teaching Assistant, GIS Lab Fall, 2017
  * Instructor of Record, Map Analysis Spring, 2018
  * Instructor of Record, Map AnalysisSummer, 2018
  * Instructor of Record, Map Analysis Fall, 2018 
