---
layout: archive
title: "Research"
permalink: /research/
author_profile: true
---

{% include base_path %}

My research agenda focuses on three interrelated areas:

1. **Civil conflict and state capacity** — I examine how state institutions shape the onset, duration, and termination of armed conflict, with particular attention to sub-Saharan Africa.

2. **Political institutions and governance** — I study how formal and informal institutions affect policy outcomes and accountability in new democracies.

3. **Methodology** — I develop and apply quantitative and computational methods for causal inference with observational data.

---

{% for post in site.research reversed %}
  {% include archive-single.html %}
{% endfor %}
