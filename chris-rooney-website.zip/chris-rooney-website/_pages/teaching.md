---
layout: archive
title: "Teaching"
permalink: /teaching/
author_profile: true
---

{% include base_path %}

I am committed to accessible, evidence-based pedagogy. Below is a summary of courses I teach or have taught. Syllabi are available upon request.

---

## University of Example

### Undergraduate Courses

**POLS 101: Introduction to Comparative Politics**  
An introductory survey of comparative politics, covering key concepts such as regime types, political parties, elections, and the political economy of development.

**POLS 320: Political Violence and Civil War**  
An upper-division course examining the causes, dynamics, and consequences of civil war, terrorism, and mass atrocities. Students engage with both qualitative case studies and quantitative research.

### Graduate Courses

**POLS 510: Research Methods in Political Science**  
A doctoral-level methods course covering research design, causal inference, regression analysis, and qualitative methods. Students complete an original research paper.

---

## Previous Institutions

**[Previous University]**  
- [Course Name] ([Year])

{% for post in site.teaching reversed %}
  {% include archive-single.html %}
{% endfor %}
