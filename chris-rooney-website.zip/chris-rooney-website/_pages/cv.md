---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}

A PDF version of my CV is available [here](/files/cv.pdf).

---

## Education

**Ph.D., Political Science**, [Graduate University], [Year]  
Dissertation: *[Dissertation Title]*  
Committee: [Advisor Name] (chair), [Member 2], [Member 3]

**M.A., Political Science**, [Graduate University], [Year]

**B.A., Political Science**, [Undergraduate University], [Year]  
*Summa Cum Laude*

---

## Academic Positions

**Assistant Professor**, Department of Political Science, University of Example, [Year]–present

**Postdoctoral Fellow**, [Postdoc Institution], [Year]–[Year]

---

## Publications

### Peer-Reviewed Articles

1. Rooney, Chris. "[Article Title One]." *American Political Science Review* XX(X): XXX–XXX. [Year].

2. Rooney, Chris. "[Article Title Two]." *Journal of Politics* XX(X): XXX–XXX. [Year].

3. Rooney, Chris, and [Co-author Name]. "[Article Title Three]." *International Organization* XX(X): XXX–XXX. [Year].

### Book Chapters

1. Rooney, Chris. "[Chapter Title]." In *[Edited Volume Title]*, edited by [Editors]. Publisher, [Year].

---

## Working Papers

- "Working Paper Title One" *(under review)*
- "Working Paper Title Two" *(working paper)*

---

## Teaching

**University of Example**
- POLS 101: Introduction to Comparative Politics (undergraduate)
- POLS 320: Political Violence and Civil War (undergraduate)
- POLS 510: Research Methods in Political Science (graduate)

---

## Awards & Fellowships

- [Fellowship Name], [Granting Institution], [Year]
- [Award Name], [Granting Institution], [Year]

---

## Professional Service

- **Reviewer**: American Political Science Review, Journal of Politics, Comparative Political Studies
- **Member**: American Political Science Association, Midwest Political Science Association

---

## References

Available upon request.
