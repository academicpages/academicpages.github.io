---
permalink: /
title: "About Me"
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

Welcome! I am an Assistant Professor of Political Science at the University of Example. My research lies at the intersection of comparative politics and international relations, with a focus on civil conflict, state capacity, and political institutions in the developing world.

I received my Ph.D. in Political Science from [Your Graduate University] in [Year]. Before joining the University of Example, I was a postdoctoral fellow at [Postdoc Institution].

My work has been published or is forthcoming in journals such as the *American Political Science Review*, the *Journal of Politics*, and *International Organization*. I am also the author of *[Book Title]* (Publisher, Year).

In addition to my research, I teach courses on comparative politics, research methods, and political violence. Please see my [CV](/cv/) for a full list of publications, courses, and other academic activities.

Feel free to reach out at [c.rooney@example.edu](mailto:c.rooney@example.edu).
