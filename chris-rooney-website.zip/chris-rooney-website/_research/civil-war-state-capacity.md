---
title: "Civil War and State Capacity in Sub-Saharan Africa"
collection: research
type: "Research Project"
permalink: /research/civil-war-state-capacity
excerpt: 'An ongoing book project examining how variation in state capacity across African countries shapes the risk of armed conflict.'
date: 2023-01-01
---

## Overview

This is my primary book project. I argue that the administrative capacity of the state — its ability to monitor, tax, and provide services to the population — is the central factor determining whether ethnic and economic grievances translate into organized violence.

## Data

The project draws on an original dataset of administrative capacity indicators for 48 African countries from 1960 to 2020, combined with conflict event data from ACLED and UCDP.

## Status

I am currently revising the manuscript for submission to a university press. A working paper version is available upon request.
