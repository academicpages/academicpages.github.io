---
title: "Article Title One"
collection: publications
permalink: /publications/2023-article-one
excerpt: 'This paper examines how state capacity mediates the relationship between ethnic diversity and civil conflict onset, using original data from sub-Saharan Africa.'
date: 2023-01-01
venue: 'American Political Science Review'
paperurl: '/files/rooney-2023-apsr.pdf'
citation: 'Rooney, Chris. (2023). &quot;Article Title One.&quot; <i>American Political Science Review</i> 117(1): 1–20.'
---

This paper examines how state capacity mediates the relationship between ethnic diversity and civil conflict onset, using original data from sub-Saharan Africa. We find that high-capacity states are significantly better able to prevent conflict even in highly diverse societies.

[Download paper here](/files/rooney-2023-apsr.pdf)

Recommended citation: Rooney, Chris. (2023). "Article Title One." <i>American Political Science Review</i> 117(1): 1–20.
