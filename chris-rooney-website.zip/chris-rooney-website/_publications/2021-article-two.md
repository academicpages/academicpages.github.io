---
title: "Article Title Two"
collection: publications
permalink: /publications/2021-article-two
excerpt: 'This paper investigates the conditions under which electoral institutions promote accountability in new democracies, drawing on a cross-national panel dataset.'
date: 2021-06-01
venue: 'Journal of Politics'
paperurl: '/files/rooney-2021-jop.pdf'
citation: 'Rooney, Chris. (2021). &quot;Article Title Two.&quot; <i>Journal of Politics</i> 83(3): 900–915.'
---

This paper investigates the conditions under which electoral institutions promote accountability in new democracies, drawing on a cross-national panel dataset covering 90 countries from 1990 to 2015.

[Download paper here](/files/rooney-2021-jop.pdf)

Recommended citation: Rooney, Chris. (2021). "Article Title Two." <i>Journal of Politics</i> 83(3): 900–915.
