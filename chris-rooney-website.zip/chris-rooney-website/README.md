# Chris Rooney — Academic Website

This repository contains the source files for Chris Rooney's academic website, built using the [academicpages](https://github.com/academicpages/academicpages.github.io) Jekyll template and hosted on GitHub Pages.

---

## Quick Setup Guide

### 1. Fork & Rename the Template

1. Fork [academicpages/academicpages.github.io](https://github.com/academicpages/academicpages.github.io) on GitHub.
2. In the repository **Settings**, rename it to `<yourusername>.github.io`.
3. Replace the template files with the files from this repository.

### 2. Key Files to Edit

| File | Purpose |
|------|---------|
| `_config.yml` | Site-wide settings: name, bio, social links |
| `_pages/about.md` | Your homepage / bio |
| `_pages/cv.md` | Your CV |
| `_data/navigation.yml` | Top navigation bar links |
| `_publications/*.md` | One file per publication |
| `_research/*.md` | One file per research project |

### 3. Add Your Photo

Place a profile photo at `images/profile.jpg`. The recommended size is 500×500 px.

### 4. Add Your CV PDF

Place your CV PDF at `files/cv.pdf`.

### 5. Run Locally (Optional)

```bash
# Install dependencies
sudo apt install ruby-dev ruby-bundler nodejs   # Linux
# or: brew install ruby                          # macOS

bundle install
bundle exec jekyll serve
# Visit http://localhost:4000
```

### 6. Push to GitHub

```bash
git add .
git commit -m "Set up site for Chris Rooney"
git push
```

Your site will be live at `https://<yourusername>.github.io` within a few minutes.

---

## Adding Publications

Create a new `.md` file in `_publications/` following the existing examples. The filename should follow the format `YYYY-short-title.md`.

## Adding Research Projects

Create a new `.md` file in `_research/` following the existing example.

---

## Credits

Built on the [academicpages](https://github.com/academicpages/academicpages.github.io) template, which is forked from the [Minimal Mistakes](https://mmistakes.github.io/minimal-mistakes/) Jekyll theme.
