return {
	[1]={
		lang={
			English={
				[1]={
					[1]={
						k="milliseconds_to_seconds_2dp",
						v=1
					},
					limit={
						[1]={
							[1]=1,
							[2]="#"
						}
					},
					text="Debuff Lasts {0} seconds"
				}
			}
		},
		name="secondary_buff_duration",
		stats={
			[1]="secondary_buff_effect_duration"
		}
	},
	parent="buff_skill_stat_descriptions",
	["secondary_buff_effect_duration"]=1
}