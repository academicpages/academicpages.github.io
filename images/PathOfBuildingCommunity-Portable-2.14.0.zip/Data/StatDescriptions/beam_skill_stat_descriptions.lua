return {
	[1]={
		lang={
			English={
				[1]={
					limit={
						[1]={
							[1]=1,
							[2]=1
						}
					},
					text="Beams Split towards {0} additional target"
				},
				[2]={
					limit={
						[1]={
							[1]="#",
							[2]="#"
						}
					},
					text="Beams Split towards {0} additional targets"
				}
			}
		},
		name="base_split_num",
		stats={
			[1]="projectile_number_to_split"
		}
	},
	parent="skill_stat_descriptions",
	["projectile_number_to_split"]=1
}