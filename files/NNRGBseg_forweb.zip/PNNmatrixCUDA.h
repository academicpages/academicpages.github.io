/*******************************************************************************
 **
 ** File: PNNMatrixCUDA.h
 ** Contains the definitions needed by the foreground segmentation algorithm.
 ** Author: Dubravko Culibrk
 ** Copyright 2009 Dubravko Culibrk
 **
 ** This file is part of NNRGBSeg - software that performs foreground segmentation 
 ** based on the Background Neural Network Approach and runs on an NVIDA CUDA GPU.
 ** 
 ** NNRGBSeg is free software: you can redistribute it and/or modify
 ** it under the terms of the GNU General Public License as published by
 ** the Free Software Foundation, either version 3 of the License, or
 ** (at your option) any later version.

 ** NNRGBSeg is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 ** GNU General Public License for more details.

 ** You should have received a copy of the GNU General Public License
 ** along with NNRGBSeg.  If not, see <http://www.gnu.org/licenses/>.
 *******************************************************************************/

#ifndef PNNMATRIXCUDA_INCLUDED
#define PNNMATRIXCUDA_INCLUDED


uchar3 *input_to_pattern_weights;//[glimage_width*glimage_height*MAX_NUMBER_OF_STORED_PATTERNS]; 
//float *output_weights;//[glimage_width*glimage_height*MAX_NUMBER_OF_STORED_PATTERNS]; 
float *pattern_neurons_sigma;//[glimage_width*glimage_height]

uchar3 *input_image;//[glimage_width*glimage_height*NUM_CHANNELS]; 
uchar3 *fg_image;//[glimage_width*glimage_height*NUM_CHANNELS]; 

//weights between the input layer and the pattern layer of the network
float *input_to_summation_weights0;//[glimage_width*glimage_height*MAX_NUMBER_OF_STORED_PATTERNS]; 
float *input_to_summation_weights1;//[glimage_width*glimage_height*MAX_NUMBER_OF_STORED_PATTERNS]; 

int *last_pattern_set;//[glimage_width*glimage_height];

float *pattern_neurons_state;//[glimage_width*glimage_height];

float *summation_neurons_state0;//[glimage_width*glimage_height];
float *summation_neurons_state1;//[glimage_width*glimage_height];

//wta emulation
float *wta_max_value; //[glimage_width*glimage_height];
int *wta_max_index;//[glimage_width*glimage_height];
int *active_nets_mask;//[glimage_width*glimage_height];

float alpha = 0.016;

float sigma = 7;

float output_weight = -1;

//activity threshold for the WTA network
float active_threshold = 0.5;

#endif