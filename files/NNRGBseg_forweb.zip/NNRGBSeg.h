/*******************************************************************************
 **
 ** File: NNRGBSeg.h
 ** Contains the definitions needed by the foreground segmentation algorithm.
 ** Author: Dubravko Culibrk
 ** Copyright 2009 Dubravko Culibrk
 **
 ** This file is part of NNRGBSeg - software that performs foreground segmentation 
 ** based on the Background Neural Network Approach and runs on an NVIDA CUDA GPU.
 ** 
 ** NNRGBSeg is free software: you can redistribute it and/or modify
 ** it under the terms of the GNU General Public License as published by
 ** the Free Software Foundation, either version 3 of the License, or
 ** (at your option) any later version.

 ** NNRGBSeg is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 ** GNU General Public License for more details.

 ** You should have received a copy of the GNU General Public License
 ** along with NNRGBSeg.  If not, see <http://www.gnu.org/licenses/>.
 *******************************************************************************/

#ifndef _BACKGROUND_DETECTION_INCLUDED
#define _BACKGROUND_DETECTION_INCLUDED
//#define glimage_height 128//480//240 //frame height  
//#define glimage_width 160//720//352 //frame width


#include <stdio.h>
#include <malloc.h>
#include <math.h>

#define NUM_CHANNELS 3
#define MAX_NUMBER_OF_STORED_PATTERNS	10//12
#define LEARNING_RATE	0.05f //0.00103f	//0.05f

//#include "GaborFilter.h"
//#include "GaussianFilter.h"

// definition of used types
//typedef unsigned char (*pmat2D)[glimage_width];
//typedef unsigned char (*pmat3D)[glimage_width][3];
//typedef unsigned char mat2D[glimage_height][glimage_width];
//typedef unsigned char mat3D[glimage_height][glimage_width][3];

//typedef int (*pimat2D)[glimage_width];
//typedef int (*pimat3D)[glimage_width][3];

#endif