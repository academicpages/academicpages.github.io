function outcome = io_price_adjust(IOT,Index,pre)
% 该函数用于价格调平
% IOT = IOT_raw; Index = Index_raw; %用于调试
% 参数设置
year = pre.year; %年份
ny = length(year); %年份数
N_all = [122,42,135,41,139,42,149,153,153]; %每个年份的原始部门

% 导入匹配标准
file_in = fullfile("source","模型附件.xlsx"); %文件名称
D_raw = readcell(file_in,"Sheet",2); %导入匹配标准数据
D_m = D_raw(:,3:3:3*ny); %对应匹配标准列

% 对IO表进行历年的调平 
IOT_new = cell(ny,1); %预设元胞存储价格调整后的IO表
for y = 1:ny 
    % y = 1; %用于调试
    D = IOT{y}; %提取第y年IO表
    Idx = Index{y}; %提取第y年价格指数
    N = N_all(y); %第y年的部门数量
    d_merge = D_m((1:N)+1,y); %提取标准数据
    d_m = zeros(N,1);
    for n = 1:N
        idx_n = d_merge{n}; %第n个部门对应的索引
        d_m(n) = Idx(idx_n); %对应的价格指数数据
    end
    % 价格调平部分
    d_hat = 1./d_m; %价格指数的倒数
    d_hat(isnan(d_hat)|isinf(d_hat)) = 1; %去除异常元素 
    IO = struct; %预设结构体存储新的IO表
    IO.Z = diag(d_hat)*D.Z; %中间产品矩阵
    IO.F = diag(d_hat)*D.F; %最终产品矩阵
    IO.EX = diag(d_hat)*D.EX; %出口向量
    IO.ERR = diag(d_hat)*D.ERR; %误差项
    IO.X = diag(d_hat)*D.X; %总产出
    IO.IM = diag(d_hat)*D.IM; %进口向量
    IO.VA = D.VA*diag(d_hat); %增加值矩阵
    IOT_new{y} = IO; %存储第y年的调整
end
outcome = IOT_new; %将结果输出到函数
end