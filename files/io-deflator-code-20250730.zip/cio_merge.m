function outcome = cio_merge(IOT,pre)
% 该函数用于IO表的合并
% IOT = IOT_raw;
% 参数设置
% G = pre.G; %地区数
% N = pre.N; %部门数
% Fn = pre.Fn; %最终需求部分数
% Vn = pre.Vn; %增加值部分数
year = pre.year; %年份
ny = length(year); %年份数
N_new = 11; %合并后的部门数量
year_all = [2002,2005,2007,2010,2012,2015,2017,2018,2020]; %所有数据时间
N_all = [122,42,135,41,139,42,149,153,153]; %每个年份的原始部门
[~,idx_y] = ismember(year,year_all); %年份索引
N_all = N_all(idx_y); %目标年份原始部门

% 导入数据
file_in = fullfile("source","模型附件.xlsx"); %合并标准数据路径
D_raw = readcell(file_in,"Sheet",1); %导入部门合并标准数据
D = D_raw(2:12,2:10); %合并标准文件
D_cell = D(:,idx_y); %目标年份合并标准
IOT_new = cell(ny,1); %预设元胞存储新的IO表
for y = 1:ny
    % y = 1; %用于调试
    MS = zeros(N_new,N_all(y));
    for n = 1:N_new
        % n = 2; %用于调试
        idx_n = D_cell{n,y}; %提取新的第n个部门对应IO部门索引
        if ischar(idx_n)
            idx_n = str2num(idx_n); %数据格式调整
        end
        MS(n,idx_n) = 1; %需要合并的置1
    end
    fprintf('合并用到部门数量%4.0d个\n',sum(MS,"all"));
    D = IOT{y}; %提取第y年的IO表
    IO = struct; %预设结构体存储新的IO表
    IO.Z = MS*D.Z*MS'; %中间产品矩阵
    IO.F = MS*D.F; %最终产品矩阵
    IO.EX = MS*D.EX; %出口向量
    IO.ERR = MS*D.ERR; %误差项
    IO.X = MS*D.X; %总产出
    IO.IM = MS*D.IM; %进口向量
    IO.VA = D.VA*MS'; %增加值矩阵
    IOT_new{y} = IO; %存储第y年的调整
end
outcome = IOT_new; %结果输出到函数
end


%% 草稿
% % 导入数据
% file_in = fullfile("source","R&D行业已合并.xlsx"); %合并标准文件
% D_raw = readcell(file_in,"Sheet","IO部门合并"); %导入合并数据
% idx_col = 2:3:26; %合并标准列
% D = D_raw(2:end,idx_col); %各年的索引
% idx_missing = cellfun(@(x) all(ismissing(x)), D); 
% idx_nm = ~idx_missing; 
% n = 1;
% num_cell = cell(ny,1); 
% for n = 1:length(num_cell)
% idx_num = find(idx_nm(:,n));
% num_cell{n} = idx_num;
% end
% Tab1 = [num2cell(year)',num_cell];
% writecell(Tab1 ,"output\getidx.xlsx");

% % 
% 
% D_cell = D_raw(2:2-1+N_new,7); %提取合并索引
% M_s = zeros(N_new,N); %预设矩阵存储部门合并矩阵
% for n = 1:N_new
%     % n = 2; %用于调试
%     idx_n = D_cell{n}; %提取新的第n个部门对应IO部门索引
%     if ischar(idx_n)
%         idx_n = str2num(idx_n); %数据格式调整
%     end
%     M_s(n,idx_n) = 1; %需要合并的置1
% end
% MS = kron(eye(G),M_s); %部门合并矩阵
% IOT_new = cell(ny,1); %预设元胞存储新的IO表
% for y = 1:ny 
%     D = IOT{y}; %提取第y年的IO表
%     IO = struct; %预设结构体存储新的IO表
%     IO.Z = MS*D.Z*MS'; %中间产品矩阵
%     IO.F = MS*D.F; %最终产品矩阵
%     IO.EX = MS*D.EX; %出口向量
%     IO.ERR = MS*D.ERR; %误差项
%     IO.X = MS*D.X; %总产出
%     IO.IM = D.IM*MS'; %进口向量
%     IO.VA = D.VA*MS'; %增加值矩阵
%     IOT_new{y} = IO; %存储第y年的调整
% end 
% outcome = IOT_new; %输出到函数结果