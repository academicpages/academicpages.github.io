% 该程序用于进行IO表的价格调平以及相关指标测算 
cd("E:\Work\20250730\code"); %设置工作路径
clc;clear;close all; %清空工作区
% 参数设置 
pre = struct; %预设结构体
pre.year = [2002,2005,2007,2010,2012,2015,2017,2018,2020]; %数据时间
%pre.year = [2002,2017,2018,2020]; %数据时间
pre.year_p = [2002,2020]; %数据时间节点
pre.folder = "source"; %数据所处文件夹
pre.N = 11; %部门数量

% 导入数据
IOT_raw = import_ciot_raw(pre); %导入原始IO数据
Index_raw = import_deflator(IOT_raw,pre); %导入价格指数数据

% 数据处理
IOT_d = io_price_adjust(IOT_raw,Index_raw,pre); %价格调平
IOT_m = cio_merge(IOT_d,pre); %部门合并

% 导出结果
Tab_IO = outshow_io(IOT_m,pre); %写入IO表