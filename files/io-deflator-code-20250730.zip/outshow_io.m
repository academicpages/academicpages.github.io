function outcome = outshow_io(IOT,pre)
% 该函数用于输出IO表
% IOT = IOT_m; %用于调试

% 参数设置
year = pre.year; %年份
ny = length(year); %年份数
file_out = "output\IOT_adj1.xlsx"; %输出文件名称
if exist(file_out,"file")
    delete(file_out);
    copyfile(fullfile("source","IOT格式参照.xlsx"),file_out);
else
    copyfile(fullfile("source","IOT格式参照.xlsx"),file_out);
end
% 导出数据
Tab_IO = cell(ny,1); %预设元胞存储表格
for y = 1:ny
    tic; %y = 1; %用于调试
    D = IOT{y}; %提取第y年的IO表
    if year(y)<=2015
        Tab_part1 = [D.Z,sum(D.Z,2),D.F(:,1:2),sum(D.F(:,1:2),2),...
            D.F(:,3),sum(D.F(:,1:3),2),D.F(:,4:5),sum(D.F(:,4:5),2),...
            D.EX,sum(D.F,2)+D.EX,D.IM,D.ERR,D.X];
    else
        Tab_part1 = [D.Z,sum(D.Z,2),D.F(:,1:2),sum(D.F(:,1:2),2),...
            D.F(:,3),sum(D.F(:,1:3),2),D.F(:,4:5),sum(D.F(:,4:5),2),...
            D.EX,sum(D.F,2)+D.EX,D.IM,D.X];
    end
    Tab_part2 = sum(Tab_part1,1);
    Tab_part3 = [D.VA,sum(D.VA,2);sum(D.VA,1),sum(D.VA,"all");D.X',sum(D.X)];
    Tab_out = [Tab_part1;Tab_part2;[Tab_part3,zeros(size(Tab_part3,1),size(Tab_part1,2)-size(Tab_part3,2))]];
    Tab_IO{y} = Tab_out; %写入元胞
    writematrix(Tab_out,file_out,"Sheet",num2str(year(y)),"Range","C3","PreserveFormat",true); %写入表格
    fprintf('已写入%4.0d年IO表，用时%4.2f秒\n',year(y),toc);
end
outcome = Tab_IO;
end