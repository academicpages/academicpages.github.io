function outcome = import_ciot_raw(pre)
% 该函数用于导入投入产出表
% 参数设置
year = pre.year; %数据年份
ny = length(year); %数据年份数
folder = pre.folder; %数据文件夹
folder_in = fullfile(folder,"IOT"); %导入数据文件
year_all = [2002,2005,2007,2010,2012,2015,2017,2018,2020]; %所有数据时间
N_all = [122,42,135,41,139,42,149,153,153]; %每个年份的原始部门
idx_rf_all = {7,7,7,7,5,9,7,7,7};
idx_cf_all = {4,4,4,4,4,4,4,4,4};
idx_f_all = {[1,2,4,6,7],1:5,[1,2,4,6,7],[1,2,4,6,7],...
    [1,2,3,5,6],[1,2,4,6,7],[1,2,4,6,7],[1,2,4,6,7],[1,2,4,6,7]}; %需+1
idx_ex_all = [{9},{6},{9},{9},{8},{9},{9},{9},{9},];
idx_im_all = [{11},{7},{11},{11},{10},{11},{11},{11},{11}];
idx_err_all = [{12},{8},{12},{12},{12},{12},{nan},{nan},{nan}];
idx_x_all = [{13},{9},{13},{13},{11},{13},{12},{12},{12}];
idx_va_all = [{1:4},{1:4},{1:4},{1:4},{1:4},{1:4},{1:4},{1:4},{1:4}]; %需+1
[~,idx_y] = ismember(year,year_all); %查看目标年份对应索引
% N = pre.N; %部门数量
% idx_z = 3:3-1+N; %中间产品部门索引
% idx_f = [15,16,18,20,21]; %最终需求列索引
% idx_va = 15:18; %增加值索引
% 导入数据
IOT = cell(ny,1); %预设元胞存储IO表
for n = 1:ny
    tic; % n = 1; %用于调试
    y = idx_y(n); %对应年份索引
    if year_all(y)<=2010
        file_type = ".xls";
    else
        file_type = ".xlsx";
    end
    file_in = fullfile(folder_in,strcat(num2str(year_all(y)),file_type));
    if year_all(y) == 2018
        D = readcell(file_in,"Sheet","生产价投入产出表"); %导入第y年数据
    else
        D = readcell(file_in,"Sheet",1); %导入第y年数据
    end
    fr = idx_rf_all{y};
    fc = idx_cf_all{y};
    idx_f = idx_f_all{y};
    idx_ex = idx_ex_all{y};
    idx_im = idx_im_all{y};
    idx_err = idx_err_all{y};
    idx_x = idx_x_all{y};
    idx_va = idx_va_all{y};
    N = N_all(y);
    idx_zr = (1:N)+fr-1;
    idx_zc = (1:N)+fc-1;
    idx_f = idx_f+N+1+fc-1; 
    idx_ex = idx_ex+N+1+fc-1;
    idx_im = idx_im+N+1+fc-1;
    idx_err = idx_err+N+1+fc-1;
    idx_x = idx_x+N+1+fc-1;
    idx_va = idx_va+N+1+fr-1; 
    % IO表的部门名称
    sector_name = D(idx_zr,2); %部门名称
    % 对应部分矩阵
    Z = cell2mat(D(idx_zr,idx_zc)); %中间产品
    F = cell2mat(D(idx_zr,idx_f)); %最终需求
    EX = cell2mat(D(idx_zr,idx_ex)); %出口
    IM = cell2mat(D(idx_zr,idx_im)); %进口
    if isnan(idx_err)
        ERR = zeros(size(Z,1),1); 
    else
    ERR = cell2mat(D(idx_zr,idx_err)); %误差项
    end
    X = cell2mat(D(idx_zr,idx_x)); %总产出
    VA = cell2mat(D(idx_va,idx_zc)); %增加值
    % % 数据核验
    X_row = sum(Z,2)+sum(F,2)+EX-IM+ERR;
    X_col = sum(Z,1)'+sum(VA,1)';
    X_check = [X,X_row,X_col];
    if all(abs(X_check(:,1)-X_check(:,2))<=1e-2)&&...
            all(abs(X_check(:,2)-X_check(:,3))<=1e-2)
        fprintf("%4.0d年IO表导入，行列平衡均满足。\n",year_all(y));
    end
    IO = struct; %预设结构体存储IO表
    IO.Z=Z; IO.F=F; IO.EX=EX; IO.IM=IM; %存储到结构体
    IO.ERR=ERR; IO.X=X; IO.VA=VA; %存储到结构体
    IO.sector_name = sector_name; %存储IO的部门名称
    IOT{n} = IO; %存储各年结果到元胞
    fprintf('导入%4.0d年数据，用时%4.2f秒\n',year_all(y),toc); %进度提示
end
outcome = IOT; %输出函数结果
end

%% 草稿
% if year(y)<=2015
%     ERR = cell2mat(D(idx_z,26)); %误差项
%     X = cell2mat(D(idx_z,27)); %总产出
% else
%     ERR = zeros(N,1); %2015年后没有误差
%     X = cell2mat(D(idx_z,26)); %总产出
% end
% VA = cell2mat(D(idx_va,idx_z)); %增加值