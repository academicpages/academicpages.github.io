function outcome = import_deflator(IOT_raw,pre)
% 该程序用于导入价格指数
% 参数设置
year = pre.year; %年份
ny = length(year); %年份数
year_base = 2010; %以2010年为基期
year_raw = 2001:2024; %原始数据所处年份
writemode = 0; %是否写入文件

% 导入数据
files1 = dir(fullfile("source","deflator")); %文件名
files2 = files1(~[files1.isdir],:); %去除文件夹
files = {files2.name}'; %文件名称
nf = length(files);
D_raw_cell = cell(nf,1);
for f = 1:nf
    file_in = fullfile("source\deflator",files{f});
    D_raw = readcell(file_in,"Sheet",1); %导入数据
    D_raw_d = D_raw(2:end,5:end); %数据部分
    idx_missing = cellfun(@(x) all(ismissing(x)),D_raw_d); %缺失数据
    nall = all(~idx_missing,2); %全部都有元素的部门
    nidx = find(nall); %对应的行
    if ~isempty(nidx)
        for n = 1:size(D_raw_d,1)
            % n = 1; %用于调试
            idx_missing_n = idx_missing(n,:); %第n个指标索引
            if any(idx_missing_n)
                D_raw_d(n,idx_missing_n) = D_raw_d(nidx(1),idx_missing_n); %缺失值填补
            end
        end
    end
    D_raw(2:end,5:end) = D_raw_d; %替补
    D_raw_cell{f} = D_raw;
end
D_raw_cell1 = cellfun(@(x) x(2:end,:),D_raw_cell,"UniformOutput",false); %去除首行
D_raw = [D_raw_cell{1}(1,:);vertcat(D_raw_cell1{:})]; %数据合并
% 二次填补
D_raw_d = D_raw(2:end,5:end); %数据部分
idx_missing = cellfun(@(x) all(ismissing(x)),D_raw_d); %缺失数据
for n = 1:size(D_raw_d,1)
    % n = 1; %用于调试
    idx_missing_n = idx_missing(n,:); %第n个指标索引
    if any(idx_missing_n)
        D_raw_d(n,idx_missing_n) = D_raw_d(1,idx_missing_n); %缺失值填补
    end
end
D_raw(2:end,5:end) = D_raw_d; %替补


% 环比价格指数调整为以某一年为基期的价格指数
D_mat = cell2mat(D_raw(2:end,5:end))./100; %价格指数单位调整
D_mat(isnan(D_mat)|isinf(D_mat)) = 1; %去除异常元素
[~,yb_idx] = ismember(year_base,year_raw); %基期年份所在位置
D_b = D_mat(:,1:yb_idx); %之前年份数据
D_b1 = fliplr(D_b); %左右翻转
D_b2 = 1./cumprod(D_b1,2); %叠除
D_b3 = D_b2(:,1:end-1); %之前年份
D_bi = fliplr(D_b3); %之前年份的指数调整
D_f = D_mat(:,yb_idx+1:end); %之后年份数据
D_f1 = cumprod(D_f,2); %价格指数(非环比)
D_fi = D_f1(:,1:end-1); %提取有效部分
D_adj = [D_bi,ones(size(D_b,1),1),D_fi]; %数据拼接

% 导出非环比价格指数
name_row = D_raw(2:end,1); %指标名称
name_row = cellfun(@(x) strrep(x,'(上年＝100)',strcat('(基期＝',num2str(year_base),')'))...
    ,name_row,"UniformOutput",false); %修改指标名称
[~,idx_y] = ismember(year,year_raw); %年份索引
D_mat_adj = D_adj(:,idx_y); %提取目标年份结果
D_mat_cell = cellfun(@(x) D_mat_adj(:,x),num2cell(1:ny)',"UniformOutput",false);
outcome = D_mat_cell; %将结果输出到函数

% 相关表格制作
Tab_d = [{'序号','价格指数'},num2cell(year);...
    num2cell(1:size(name_row,1))',name_row,num2cell(D_adj(:,idx_y))]; %制作价格指数表格
if writemode == 1
    writecell(Tab_d,"output\目标年份价格指数.xlsx","Sheet","价格指数"); %导出价格指数
end
% IO表的部门名称
sector_name1 = cellfun(@(x) x.sector_name,IOT_raw,"UniformOutput",false); %提取IO表部门名称
sector_name2 = cellfun(@(x) [num2cell(1:length(x))',x],sector_name1,"UniformOutput",false); %添加序号
Tab_sector = cellfun(@(x1,x2) [{'序号',x1};x2],num2cell(year)',sector_name2,"UniformOutput",false); %制作表格
Tab_sector_m = cellfun(@(x) [x,[{'匹配'};num2cell(ones(size(x,1)-1,1))]],...
    Tab_sector,"UniformOutput",false); %添加匹配列

% 统一维度
C = Tab_sector_m; %重新定义表格
maxRows = max(cellfun(@height, C)); %寻找最大数据列
for i = 1:length(C)
    [rows, cols] = size(C{i}); %确定维度
    if rows < maxRows
        padding = cell(maxRows - rows, cols); %预制空元胞
        C{i} = [C{i}; padding]; %添加空元胞
    end
end
C_padded = C; %统一维度
Tab_sector = [C_padded{:}]; %合并在一起
if writemode == 1
    writecell(Tab_sector,"output\目标年份价格指数.xlsx","Sheet","匹配预文件"); %写入与匹配表格
end
% 数据核验
% check_round = diff(D_adj,[],2)./D_adj(:,1:end-1)+1;
end

%% 草稿
% % 数据预处理
% file_in = fullfile("source","各种价格指数.xls");
% D_raw1 = readcell(file_in,"Sheet",1); %导入数据
% D_raw_d = D_raw1(2:end,5:end); %数据部分
% idx_missing = cellfun(@(x) all(ismissing(x)),D_raw_d); %缺失数据
% for n = 1:size(D_raw_d,1)
%     % n = 1; %用于调试
%     idx_missing_n = idx_missing(n,:); %第n个指标索引
%     if any(idx_missing_n)
%         D_raw_d(n,idx_missing_n) = D_raw_d(1,idx_missing_n); %缺失值填补
%     end
% end
% D_raw1(2:end,5:end) = D_raw_d; %替补
% file_in = fullfile("source","按工业行业分工业生产者出厂价格指数.xls");
% D_raw2 = readcell(file_in,"Sheet",1); %导入数据
% D_raw_d = D_raw2(2:end,5:end); %数据部分
% idx_missing = cellfun(@(x) all(ismissing(x)),D_raw_d); %缺失数据
% for n = 1:size(D_raw_d,1)
%     % n = 1; %用于调试
%     idx_missing_n = idx_missing(n,:); %第n个指标索引
%     if any(idx_missing_n)
%         D_raw_d(n,idx_missing_n) = D_raw_d(1,idx_missing_n); %缺失值填补
%     end
% end
% D_raw2(2:end,5:end) = D_raw_d; %替补
% file_in = fullfile("source","农产品生产价格指数.xls");
% D_raw3 = readcell(file_in,"Sheet",1); %导入数据
% D_raw_d = D_raw3(2:end,5:end); %数据部分
% idx_missing = cellfun(@(x) all(ismissing(x)),D_raw_d); %缺失数据
% for n = 1:size(D_raw_d,1)
%     % n = 1; %用于调试
%     idx_missing_n = idx_missing(n,:); %第n个指标索引
%     if any(idx_missing_n)
%         D_raw_d(n,idx_missing_n) = D_raw_d(1,idx_missing_n); %缺失值填补
%     end
% end
% D_raw3(2:end,5:end) = D_raw_d; %替补
% D_raw = [D_raw1;D_raw2(2:end,:);D_raw3(2:end,:)]; %合并