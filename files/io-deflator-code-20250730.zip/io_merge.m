function outcome = io_merge(IOT,pre)
% 该函数用于IO表的合并
% IOT = IOT_raw;
% 参数设置
G = pre.G; %地区数
N = pre.N; %部门数
% Fn = pre.Fn; %最终需求部分数
% Vn = pre.Vn; %增加值部分数
year = pre.year; %年份
ny = length(year); %年份数
N_new = 17; %合并后的部门数量

% 导入数据
file_in = fullfile("source","模型附件.xlsx"); %合并标准文件
D_raw = readcell(file_in,"Sheet","Sheet1"); %导入合并数据
D_cell = D_raw(2:2-1+N_new,7); %提取合并索引
M_s = zeros(N_new,N); %预设矩阵存储部门合并矩阵
for n = 1:N_new
    % n = 2; %用于调试
    idx_n = D_cell{n}; %提取新的第n个部门对应IO部门索引
    if ischar(idx_n)
        idx_n = str2num(idx_n); %数据格式调整
    end
    M_s(n,idx_n) = 1; %需要合并的置1
end
MS = kron(eye(G),M_s); %部门合并矩阵
IOT_new = cell(ny,1); %预设元胞存储新的IO表
for y = 1:ny 
    D = IOT{y}; %提取第y年的IO表
    IO = struct; %预设结构体存储新的IO表
    IO.Z = MS*D.Z*MS'; %中间产品矩阵
    IO.F = MS*D.F; %最终产品矩阵
    IO.EX = MS*D.EX; %出口向量
    IO.ERR = MS*D.ERR; %误差项
    IO.X = MS*D.X; %总产出
    IO.IM = D.IM*MS'; %进口向量
    IO.VA = D.VA*MS'; %增加值矩阵
    IOT_new{y} = IO; %存储第y年的调整
end 
outcome = IOT_new; %输出到函数结果
end