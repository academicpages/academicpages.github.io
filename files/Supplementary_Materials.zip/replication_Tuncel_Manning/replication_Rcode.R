# REPLICATION --------------------------------------------------------------

# ``Building democracy after war? Post-rebel electoral parties and the 
# construction of stable party systems'' in Party Politics 

# Authors:
# Ozlem Tuncel (otuncelgurlek1@gsu.edu)
# Carrie Manning (cmanning2@gsu.edu)

# This analysis conducted using R version 4.2.0

# LOAD PACKAGES ------------------------------------------------------------
# Install these packages using install.packages() if necessary
library(tidyverse) # tidyverse 1.3.1
library(lmtest)
library(sandwich)
library(stargazer)

# getwd()
# setwd()

# UPLOAD DATA --------------------------------------------------------------
prep_data <- read.csv("replication_data_pp.csv")

# SUBSET DATA --------------------------------------------------------------
# For parties with at least 20 years of experience
prep_data_20yrs <- prep_data %>% 
  group_by(party_acronym) %>% 
  mutate(year_dif = max(year) - min(year) + 1) %>% 
  filter(year_dif > 19)

# MAIN REGRESSIONS USED IN THE ANALYSIS
model1 <- lm(v2xps_party ~ consistency + v2x_polyarchy + europe + asia + africa + 
               americas + mid_east + prewar_party, data = prep_data)

model2 <- lm(v2xps_party ~ consistency + v2x_polyarchy + europe + asia + africa + 
               americas + mid_east + prewar_party, data = prep_data_20yrs)

model3 <- lm(pis_5 ~ consistency + v2x_polyarchy + europe + asia + africa + 
               americas + mid_east + prewar_party, data = prep_data)

model4 <- lm(pis_5 ~ consistency + v2x_polyarchy + europe + asia + africa + 
               americas + mid_east + prewar_party, data = prep_data_20yrs)

model1_rc <- coeftest(model1, vcov = vcovCL, type = "HC1", cluster = ~country_name)
model2_rc <- coeftest(model2, vcov = vcovCL, type = "HC1", cluster = ~country_name)
model3_rc <- coeftest(model3, vcov = vcovCL, type = "HC1", cluster = ~country_name)
model4_rc <- coeftest(model4, vcov = vcovCL, type = "HC1", cluster = ~country_name)

stargazer(model1, model3, model2, model4, type = "text")

stargazer(model1_rc, model3_rc, model2_rc, model4_rc, 
          type = "html", 
          out="models1.htm",
          covariate.labels = c("Consistency", "Democracy", "Europe", "Asia",
                               "Africa", "Americas", "Prewar party"))

# ROBUSTNESS CHECKS
# Robustness check - Freedom House civil liberties
fh_model1 <- lm(v2xps_party ~ consistency + e_fh_cl + europe + asia + africa + 
                  americas + mid_east + prewar_party, data = prep_data)
fh_model2 <- lm(v2xps_party ~ consistency + e_fh_cl + europe + asia + africa + 
                  americas + mid_east + prewar_party, data = prep_data_20yrs)
fh_model3 <- lm(pis_5 ~ consistency + e_fh_cl + europe + asia + africa + 
                  americas + mid_east + prewar_party, data = prep_data)
fh_model4 <- lm(pis_5 ~ consistency + e_fh_cl + europe + asia + africa + 
                  americas + mid_east + prewar_party, data = prep_data_20yrs)

fh_model1_rc <- coeftest(fh_model1, vcov = vcovCL, type = "HC1", cluster = ~country_name)
fh_model2_rc <- coeftest(fh_model2, vcov = vcovCL, type = "HC1", cluster = ~country_name)
fh_model3_rc <- coeftest(fh_model3, vcov = vcovCL, type = "HC1", cluster = ~country_name)
fh_model4_rc <- coeftest(fh_model4, vcov = vcovCL, type = "HC1", cluster = ~country_name)

stargazer(fh_model1, fh_model3, fh_model2, fh_model4, type = "text")

stargazer(fh_model1_rc, fh_model3_rc, fh_model2_rc, fh_model4_rc, 
          type = "html", 
          out="models_fh.htm",
          covariate.labels = c("Consistency", "Freedom House Civil Liberties", 
                               "Europe", "Asia", "Africa", "Americas", "Prewar party"))

# Robustness check - Polity IV Scores
p_model1 <- lm(v2xps_party ~ consistency + e_p_polity + europe + asia + africa + 
                 americas + mid_east + prewar_party, data = prep_data)
p_model2 <- lm(v2xps_party ~ consistency + e_p_polity + europe + asia + africa + 
                 americas + mid_east + prewar_party, data = prep_data_20yrs)
p_model3 <- lm(pis_5 ~ consistency + e_p_polity + europe + asia + africa + 
                 americas + mid_east + prewar_party, data = prep_data)
p_model4 <- lm(pis_5 ~ consistency + e_p_polity + europe + asia + africa + 
                 americas + mid_east + prewar_party, data = prep_data_20yrs)

p_model1_rc <- coeftest(p_model1, vcov = vcovCL, type = "HC1", cluster = ~country_name)
p_model2_rc <- coeftest(p_model2, vcov = vcovCL, type = "HC1", cluster = ~country_name)
p_model3_rc <- coeftest(p_model3, vcov = vcovCL, type = "HC1", cluster = ~country_name)
p_model4_rc <- coeftest(p_model4, vcov = vcovCL, type = "HC1", cluster = ~country_name)

stargazer(p_model1, p_model3, p_model2, p_model4, type = "text")

stargazer(p_model1_rc, p_model3_rc, p_model2_rc, p_model4_rc, 
          type = "html", 
          out="models_polity.htm",
          covariate.labels = c("Consistency", "Polity IV", "Europe", "Asia", 
                               "Africa", "Americas", "Prewar party"))
