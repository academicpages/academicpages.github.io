Building democracy after war? 
Post-rebel electoral parties and the construction of stable party systems 

PARTY POLITICS 
---------------

Author(s):
----------
Ozlem Tuncel - otuncelgurlek1@gsu.edu
Carrie Manning - cmanning2@gsu.edu

Corresponding author:
---------------------
Ozlem Tuncel - otuncelgurlek1@gsu.edu


Files for replication:
------------------------
- replication_Rcode.R, R file for regressions, 5,152 bytes
- replication_data_pp.csv, dataset, 22,721 bytes
- Codeboook_PartyPolitics.pdf, codebook for the dataset, 153,009 bytes