function outcome = import_ciot(pre)
% 该函数用于导入投入产出表
% 参数设置
year = pre.year; %数据年份
ny = length(year); %数据年份数
folder = pre.folder; %数据文件夹
file_in = fullfile(folder,"IOT.xlsx"); %导入数据文件
N = pre.N; %部门数量
idx_z = 3:3-1+N; %中间产品部门索引
idx_f = [15,16,18,20,21]; %最终需求列索引
idx_va = 15:18; %增加值索引
% 导入数据
IOT = cell(ny,1); %预设元胞存储IO表
for y = 1:ny
    tic; % y = 1; %用于调试
    D = readcell(file_in,"Sheet",num2str(year(y))); %导入第y年数据
    Z = cell2mat(D(idx_z,idx_z)); %中间产品
    F = cell2mat(D(idx_z,idx_f)); %最终需求
    EX = cell2mat(D(idx_z,23)); %出口
    IM = cell2mat(D(idx_z,25)); %进口
    if year(y)<=2015
        ERR = cell2mat(D(idx_z,26)); %误差项
        X = cell2mat(D(idx_z,27)); %总产出
    else
        ERR = zeros(N,1); %2015年后没有误差
        X = cell2mat(D(idx_z,26)); %总产出
    end
    VA = cell2mat(D(idx_va,idx_z)); %增加值
    % % 数据核验
    % X_row = sum(Z,2)+sum(F,2)+EX-IM+ERR;
    % X_col = sum(Z,1)'+sum(VA,1)';
    % X_check = [X,X_row,X_col];
    IO = struct; %预设结构体存储IO表
    IO.Z=Z; IO.F=F; IO.EX=EX; IO.IM=IM; %存储到结构体
    IO.ERR=ERR; IO.X=X; IO.VA=VA; %存储到结构体
    IOT{y} = IO; %存储各年结果到元胞
    fprintf('导入%4.0d年数据，用时%4.2f秒\n',year(y),toc); %进度提示
end
outcome = IOT; %输出函数结果
end