function outcome = import_eco(pre)
% 该函数用于导入排放强度 

% 参数设置
year = pre.year; %年份
ny = length(year); %年份数
folder = pre.folder; %数据文件夹
file_in = fullfile(folder,"强度.xlsx"); %文件路径 
N = pre.N; %部门数
% 导入数据
D = readcell(file_in,"Sheet","Sheet1"); %导入数据
E = cell2mat(D(2:2-1+N,2:2-1+ny)); %数据内容
E_cell = cellfun(@(x) E(:,x),num2cell(1:ny),...
    "UniformOutput",false)'; %转换为元胞
outcome = E_cell; %输出到函数结果
end