function outcome = caculate_spd_detail_nonF(IOT,ECO,pre)
% 该函数用于测算SPD

% 参数设置
year = pre.year; %年份
N = pre.N; %部门数
year_p = pre.year_p; %时间节点
nyp = length(year_p); %时间节点数量
nt = 2; %基期和报告期节点数量
[~,idx_py] = ismember(year_p,year); %年份索引
ne = 4; %详细展开层级数量
% exponential = 0:8; %生产层级
% ne = length(exponential); %生产层级数
% 逐年计算
SPD_detail = cell(nyp-1,1); %预设元胞存储SPD结果
M_m = zeros(6,3);
M_m(1:3,1) = 1;
M_m(4:5,2) = 1;
M_m(6,3) = 1;
for y = 1:nyp-1
    % y = 1; %用于调试
    tic; % y = 1; %用于调试
    S1 = cell(nt,1); %预设元胞存储基期和报告期因素
    S2 = cell(nt,1); %预设元胞存储基期和报告期因素
    S3 = cell(nt,1); %预设元胞存储基期和报告期因素
    S4 = cell(nt,1); %预设元胞存储基期和报告期因素
    for t = 1:nt
        yt = idx_py(y+t-1);
        IO = IOT{yt}; %提取基期/报告期IO表
        EC = ECO{yt}; %提取基期/报告期排放强度
        F0 = [IO.F,IO.EX-IO.IM]; %最终需求
        F = F0*M_m; %最终需求（消费、投资、净出口）
        X_hat = 1./IO.X; %总产出倒数
        A = IO.Z*diag(X_hat); %直接消耗系数矩阵
        Y1 = F./sum(F,1); %最终需求结构
        Y2 = sum(F,1); %最终需求规模
        S1{t}=EC'; S2{t}=A;
        S3{t}=Y1;
        S4{t}=Y2'; %赋值到元胞
    end
    %v_threshold = 1e-1; %设置阈值
    v_threshold = 0; %设置阈值
    % L_0层级 I
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    L_value = zeros(1,4); %预设矩阵存储层级
    tic;
    for n1 = 1:N
        % n1 = 1; %用于调试
        L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
        L2{1}(n1,n1) = 1; L2{2}(n1,n1) = 1;
        sda = sub_c_sda(S1,L2,S3,S4); %SDA分解
        S_L_0 = sum(sda,2); %总变化量
        if abs(S_L_0)>=v_threshold
            n_row = n_row+1;
            L_idx(n_row,1) = n1;
            L_value(n_row,:) = sda;
        end
    end
    L_0 = [L_idx,L_value];
    toc;
    % L_1层级 A^1
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    L_value = zeros(1,4); %预设矩阵存储层级
    tic;
    for n1 = 1:N
        for n2 = 1:N
            L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
            L2{1}(n1,n2) = S2{1}(n1,n2); L2{2}(n1,n2) = S2{2}(n1,n2);
            sda = sub_c_sda(S1,L2,S3,S4); %SDA分解
            val = sum(sda,2); %总变化量
            if abs(val)>=v_threshold
                n_row = n_row+1;
                L_idx(n_row,1) = n1;
                L_idx(n_row,2) = n2;
                L_value(n_row,:) = sda;
            end
        end
    end
    toc;
    L_1 = [L_idx,L_value];
    % L_2层级 A^2
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    L_value = zeros(1,4); %预设矩阵存储层级
    tic;
    for n1 = 1:N
        for n2 = 1:N
            for n3 = 1:N
                L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
                L2{1}(n1,n2) = S2{1}(n1,n2)*S2{1}(n2,n3);
                L2{2}(n1,n2) = S2{2}(n1,n2)*S2{2}(n2,n3);
                sda = sub_c_sda(S1,L2,S3,S4); %SDA分解
                val = sum(sda,2); %总变化量
                if abs(val)>=v_threshold
                    n_row = n_row+1;
                    L_idx(n_row,1) = n1;
                    L_idx(n_row,2) = n2;
                    L_idx(n_row,3) = n3;
                    L_value(n_row,:) = sda;
                end
            end
        end
    end
    toc;
    L_2 = [L_idx,L_value];
    % L_3层级 A^3
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    L_value = zeros(1,4); %预设矩阵存储层级
    for n1 = 1:N
        tic;
        for n2 = 1:N
            for n3 = 1:N
                for n4 = 1:N
                    L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
                    L2{1}(n1,n2) = S2{1}(n1,n2)*S2{1}(n2,n3)*S2{1}(n3,n4);
                    L2{2}(n1,n2) = S2{2}(n1,n2)*S2{2}(n2,n3)*S2{2}(n3,n4);
                    sda = sub_c_sda(S1,L2,S3,S4); %SDA分解
                    val = sum(sda,2); %总变化量
                    if abs(val)>=v_threshold
                        n_row = n_row+1; %行数加1
                        L_idx(n_row,1) = n1;
                        L_idx(n_row,2) = n2;
                        L_idx(n_row,3) = n3;
                        L_idx(n_row,4) = n4;
                        L_value(n_row,:) = sda;
                    end
                end
            end
        end
    end
    L_3 = [L_idx,L_value];
    SL = [L_0;L_1;L_2;L_3]; %结果
    SPD_detail{y} = SL; %存储第y年结果
    fprintf('已计算%4.0d年-%4.0d年SPD_detail结果，用时%4.3f秒\n',...
        year(idx_py(y)),year(idx_py(y+1)),toc); %记录进度
end
outcome = SPD_detail;
end

