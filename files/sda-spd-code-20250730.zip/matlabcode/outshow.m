function outshow(SDA,SPD,SPD_detail,SPD_detail_f,pre)
% 输出结果示例

% 参数设置
year = pre.year; %年份
N = pre.N; %部门数
year_p = pre.year_p; %时间节点
nyp = length(year_p); %时间节点数量
exponential = 0:8; %生产层级
ne = 4; %详细展开层级数量
writemode = 1; %导出大数据参数
[~,idx_py] = ismember(year_p,year); %年份索引
file_out = fullfile("output","输出结果.xlsx");
names = cellfun(@(x) strcat('S',num2str(x)),...
    num2cell(1:N),"UniformOutput",false)'; %部门名
namec = {'效应1','效应2','效应3','效应4'};
nameL = cellfun(@(x) strcat('L-',num2str(x)),...
    num2cell(exponential),"UniformOutput",false)'; %部门名
nameL{end} = 'L-all';
named = cellfun(@(x) strcat('L-',num2str(x)),...
    num2cell((1:ne)-1),"UniformOutput",false)'; %部门名
% 导出
Tab_sda = cell(nyp,1);
Tab_spd = cell(nyp,1);
Tab_spd_detail = cell(nyp,1);
Tab_spd_detail_f = cell(nyp,1); 
for y = 1:nyp-1
    % y = 1;
    % SDA
    Tab = [cell(1),namec;names,num2cell(SDA{y})];
    str_1 = sprintf('%4.0d年-%4.0d年',year(idx_py(y)),year(idx_py(y+1)));
    Tab{1} = str_1; %首个元素
    Tab_sda{y} = Tab;
    % SPD
    Tab = [cell(1),namec;nameL,num2cell(cell2mat(SPD(y,:)'))];
    Tab_spd{y} = Tab;
    % SPD detail nonf 
    Tab = [named',namec;num2cell(SPD_detail{y})];
    Tab_spd_detail{y} = Tab;
    if writemode==1
        writecell(Tab,fullfile("output",strcat("SPD_path",str_1,".csv")));
    end
    % SPD detail f 
    Tab = [named',{'f'},namec;num2cell(SPD_detail_f{y})];
    Tab_spd_detail_f{y} = Tab;
    if writemode==1
        writecell(Tab,fullfile("output",strcat("SPDf_path",str_1,".csv")));
    end
    fprintf('已计算%4.0d年-%4.0d年SDA结果，用时%4.3f秒\n',...
        year(idx_py(y)),year(idx_py(y+1)),toc); %记录进度
end
SDA_all = vertcat(Tab_sda{:});
SPD_all = vertcat(Tab_spd{:});
writecell(SDA_all,file_out,"Sheet","SDA");
writecell(SPD_all,file_out,"Sheet","SPD");

end