function outcome = caculate_spd_detail_f(IOT,ECO,pre)
% 该函数用于测算SPD

% 参数设置
year = pre.year; %年份
N = pre.N; %部门数
nf = 3; %最终需求部分数量
year_p = pre.year_p; %时间节点
nyp = length(year_p); %时间节点数量
nt = 2; %基期和报告期节点数量
[~,idx_py] = ismember(year_p,year); %年份索引
ne = 4; %详细展开层级数量
% exponential = 0:8; %生产层级
% ne = length(exponential); %生产层级数
% 逐年计算
SPD_detail = cell(nyp-1,1); %预设元胞存储SPD结果
M_m = zeros(6,3);
M_m(1:3,1) = 1;
M_m(4:5,2) = 1;
M_m(6,3) = 1;
for y = 1:nyp-1
    % y = 1; %用于调试
    tic; % y = 1; %用于调试
    S1 = cell(nt,1); %预设元胞存储基期和报告期因素
    S2 = cell(nt,1); %预设元胞存储基期和报告期因素
    S3 = cell(nt,3); %预设元胞存储基期和报告期因素
    S4 = cell(nt,3); %预设元胞存储基期和报告期因素
    for t = 1:nt
        yt = idx_py(y+t-1);
        IO = IOT{yt}; %提取基期/报告期IO表
        EC = ECO{yt}; %提取基期/报告期排放强度
        F0 = [IO.F,IO.EX-IO.IM]; %最终需求
        F = F0*M_m; %最终需求
        X_hat = 1./IO.X; %总产出倒数
        A = IO.Z*diag(X_hat); %直接消耗系数矩阵
        Y1 = F./sum(F,1); %最终需求结构
        Y1(isnan(Y1)|isinf(Y1)) = 0; %异常值处理
        Y2 = sum(F,1); %最终需求规模
        S1{t}=EC'; S2{t}=A;
        for f = 1:nf
            S3{t,f}=Y1(:,f);
            S4{t,f}=Y2(:,f)'; %赋值到元胞
        end
    end
    %v_threshold = 1e-1; %设置阈值
    v_threshold = 0; %设置阈值
    % L_0层级 I
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    Lf_idx = zeros(1); %预设矩阵存储最终需求类别
    L_value = zeros(1,4); %预设矩阵存储层级
    tic;
    for n1 = 1:N
        % n1 = 1; %用于调试
        L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
        L2{1}(n1,n1) = 1; L2{2}(n1,n1) = 1;
        for f = 1:nf
            % fprintf("外循环%2.0d",f);
            L3 = S3(:,f); %需求结构（基期和报告期）
            L4 = S4(:,f); %需求规模（基期和报告期）
            sda = sub_c_sda(S1,L2,L3,L4); %SDA分解
            S_L_0 = sum(sda,2); %总变化量
            if abs(S_L_0)>=v_threshold
                n_row = n_row+1;
                L_idx(n_row,1) = n1;
                Lf_idx(n_row,1) = f;
                % fprintf("内循环%2.0d\n",f);
                L_value(n_row,:) = sda;
            end
        end
    end
    L_0 = [L_idx,Lf_idx,L_value];
    toc;
    % L_1层级 A^1
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    Lf_idx = zeros(1); %预设矩阵存储最终需求类别
    L_value = zeros(1,4); %预设矩阵存储层级
    tic;
    for n1 = 1:N
        for n2 = 1:N
            L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
            L2{1}(n1,n2) = S2{1}(n1,n2); L2{2}(n1,n2) = S2{2}(n1,n2);
            for f = 1:nf
                % fprintf("外循环%2.0d",f);
                L3 = S3(:,f); %需求结构（基期和报告期）
                L4 = S4(:,f); %需求规模（基期和报告期）
                sda = sub_c_sda(S1,L2,L3,L4); %SDA分解
                val = sum(sda,2); %总变化量
                if abs(val)>=v_threshold
                    n_row = n_row+1;
                    L_idx(n_row,1) = n1;
                    L_idx(n_row,2) = n2;
                    Lf_idx(n_row,1) = f;
                    L_value(n_row,:) = sda;
                end
            end
        end
    end
    toc;
    L_1 = [L_idx,Lf_idx,L_value];
    % L_2层级 A^2
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    L_value = zeros(1,4); %预设矩阵存储层级
    tic;
    for n1 = 1:N
        for n2 = 1:N
            for n3 = 1:N
                L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
                L2{1}(n1,n2) = S2{1}(n1,n2)*S2{1}(n2,n3);
                L2{2}(n1,n2) = S2{2}(n1,n2)*S2{2}(n2,n3);
                for f = 1:nf
                    % fprintf("外循环%2.0d",f);
                    L3 = S3(:,f); %需求结构（基期和报告期）
                    L4 = S4(:,f); %需求规模（基期和报告期）
                    sda = sub_c_sda(S1,L2,L3,L4); %SDA分解
                    val = sum(sda,2); %总变化量
                    if abs(val)>=v_threshold
                        n_row = n_row+1;
                        L_idx(n_row,1) = n1;
                        L_idx(n_row,2) = n2;
                        L_idx(n_row,3) = n3;
                        Lf_idx(n_row,1) = f;
                        L_value(n_row,:) = sda;
                    end
                end
            end
        end
    end
    toc;
    L_2 = [L_idx,Lf_idx,L_value];
    % L_3层级 A^3
    n_row = 0; %行计数器
    L_idx = zeros(1,ne); %预设矩阵存储路径
    L_value = zeros(1,4); %预设矩阵存储层级
    for n1 = 1:N
        tic;
        for n2 = 1:N
            for n3 = 1:N
                for n4 = 1:N
                    L2{1} = zeros(N);L2{2} = zeros(N); %设置路径的
                    L2{1}(n1,n2) = S2{1}(n1,n2)*S2{1}(n2,n3)*S2{1}(n3,n4);
                    L2{2}(n1,n2) = S2{2}(n1,n2)*S2{2}(n2,n3)*S2{2}(n3,n4);
                    for f = 1:nf
                        % fprintf("外循环%2.0d",f);
                        L3 = S3(:,f); %需求结构（基期和报告期）
                        L4 = S4(:,f); %需求规模（基期和报告期）
                        sda = sub_c_sda(S1,L2,L3,L4); %SDA分解
                        val = sum(sda,2); %总变化量
                        if abs(val)>=v_threshold
                            n_row = n_row+1; %行数加1
                            L_idx(n_row,1) = n1;
                            L_idx(n_row,2) = n2;
                            L_idx(n_row,3) = n3;
                            L_idx(n_row,4) = n4;
                            Lf_idx(n_row,1) = f;
                            L_value(n_row,:) = sda;
                        end
                    end
                end
            end
        end
    end
    L_3 = [L_idx,Lf_idx,L_value];
    SL = [L_0;L_1;L_2;L_3]; %结果
    SPD_detail{y} = SL; %存储第y年结果
    fprintf('已计算%4.0d年-%4.0d年SPD_detail结果，用时%4.3f秒\n',...
        year(idx_py(y)),year(idx_py(y+1)),toc); %记录进度
end
outcome = SPD_detail;
end
% 
% %% 草稿
% L_0_check1 = sum(L_0(1:3,:),1);
% 
% L_0_check1 = sum(L_0(1:3,6:9),1);
% 
% L_0_check2 = sum(L_0(4:6,6:9),1);
% 
% L_0_check3 = sum(L_0(7:9,6:9),1);
% 
% L_0_check4 = sum(L_0(10:12,6:9),1);
% 
% 
% L_0_check = [L_0_check1;L_0_check2;L_0_check3;L_0_check4];
% 
% L_0_c = sum(L_0(:,6:9),1);