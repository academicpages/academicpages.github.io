function outcome = caculate_spd(IOT,ECO,pre)
% 该函数用于SPD计算
%   SPD为SDA和SPA结合，核心计算不同路径的四因素贡献
% 参数设置
year = pre.year; %年份
N = pre.N; %部门数
year_p = pre.year_p; %时间节点
nyp = length(year_p); %时间节点数量
nt = 2; %基期和报告期节点数量
[~,idx_py] = ismember(year_p,year); %年份索引
exponential = 0:8; %生产层级
ne = length(exponential); %生产层级数
% 逐年计算
% 整体
SPD = cell(nyp-1,ne); %预设元胞存储计算结果
for y = 1:nyp-1
    for n = 1:ne
        tic; % y = 1; n=2; %用于调试
        S1 = cell(nt,1); %预设元胞存储基期和报告期因素
        S2 = cell(nt,1); %预设元胞存储基期和报告期因素
        S3 = cell(nt,1); %预设元胞存储基期和报告期因素
        S4 = cell(nt,1); %预设元胞存储基期和报告期因素
        for t = 1:nt
            yt = idx_py(y+t-1);
            IO = IOT{yt}; %提取基期/报告期IO表
            EC = ECO{yt}; %提取基期/报告期排放强度
            F = [IO.F,IO.EX-IO.IM]; %最终需求
            X_hat = 1./IO.X; %总产出倒数
            A = IO.Z*diag(X_hat); %直接消耗系数矩阵
            if n==ne
                I = eye(N); %单位矩阵
                L = I/(I-A); %全部层级
            else
                L = A^(exponential(n)); %Leontief逆矩阵
            end
            Y1 = F./sum(F,1); %最终需求结构
            Y2 = sum(F,1); %最终需求规模
            S1{t}=EC'; S2{t}=L;S3{t}=Y1;S4{t}=Y2'; %赋值到元胞
        end
        D1 = 1/2*((S1{2}-S1{1})*S2{2}*S3{2}*S4{2}+...
            (S1{2}-S1{1})*S2{1}*S3{1}*S4{1}); %分解1
        D2 = 1/2*(S1{1}*(S2{2}-S2{1})*S3{2}*S4{2}+...
            S1{2}*(S2{2}-S2{1})*S3{1}*S4{1}); %分解2
        D3 = 1/2*(S1{1}*S2{1}*(S3{2}-S3{1})*S4{2}+...
            S1{2}*S2{2}*(S3{2}-S3{1})*S4{1}); %分解3
        D4 = 1/2*(S1{1}*S2{1}*S3{1}*(S4{2}-S4{1})+...
            S1{2}*S2{2}*S3{2}*(S4{2}-S4{1})); %分解4
        % % 结果核验
        % D_check1 = D1+D2+D3+D4; %因素和
        % D_check2 = S1{2}*S2{2}*S3{2}*S4{2}-S1{1}*S2{1}*S3{1}*S4{1}; %变动量
        % D_check = [D_check1,D_check2]; %进行比较
        SPD{y,n} = [D1,D2,D3,D4]; %存储结果
    end
    fprintf('已计算%4.0d年-%4.0d年SPD_all结果，用时%4.3f秒\n',...
        year(idx_py(y)),year(idx_py(y+1)),toc); %记录进度
end
outcome = SPD; %结果输出到函数
end