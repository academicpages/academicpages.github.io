% 该程序用于SDA和SPD的函数实例
cd("E:\Work\20250729\code"); %设置工作路径
clc;clear;close all; %清空工作区
% 参数设置 
pre = struct; %预设结构体
pre.year = [2002,2005,2007,2010,2012,2015,2017,2018,2020]; %数据时间
pre.year_p = [2002,2020]; %数据时间节点
pre.folder = "source"; %数据所处文件夹
pre.N = 11; %部门数量

% 导入数据
IOT = import_ciot(pre); %导入投入产出表
ECO = import_eco(pre); %导入二氧化碳强度数据

% 计算
SDA = caculate_sda(IOT,ECO,pre); %计算SDA
SPD = caculate_spd(IOT,ECO,pre); %计算SPD
SPD_detail = caculate_spd_detail_nonF(IOT,ECO,pre); %计算SPD具体路径
SPD_detail_f = caculate_spd_detail_f(IOT,ECO,pre); %计算SPD具体路径（区分最终需求）

% 结果
outshow(SDA,SPD,SPD_detail,SPD_detail_f,pre)