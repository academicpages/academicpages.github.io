import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import time

def read_data(file):
    data = []
    with open(file, 'r') as f:
        for line in f:
            line = line.strip().split('\t')
            data.append(line)
    return data

def plot_data(data):
    unique_labels = list(set(arr[0] for arr in data))
    print(f"total labels: {len(unique_labels)}")
    colors = plt.cm.get_cmap('tab10', len(unique_labels))

    # Plot each time series with the corresponding color
    for arr in data:
        label = arr[0]
        ts = np.array(arr[1:]).astype(float)
        color = colors(unique_labels.index(label))
        plt.plot(ts, color=color)

    # plt.legend(unique_labels, loc='right')
    plt.show()

def dp(signal1, signal2, window_size, dst_criterion):
    if dst_criterion == 'abs':
        dst_mat = np.abs(signal1[:, np.newaxis] - signal2)
    else:
        raise ValueError('Invalid distance criterion')

    M, N = len(signal1), len(signal2)
    cost_mat = np.full((M, N), np.inf)  # 代价矩阵
    window_size = max(window_size, abs(M - N))  # 窗口大小至少为两个序列长度之差

    # 初始化起始点
    cost_mat[0, 0] = dst_mat[0, 0]
    
    # 填充代价矩阵，同时使用窗口限制
    for i in range(M):
        for j in range(max(0, i - window_size), min(N, i + window_size + 1)):
            if i == 0 and j == 0:
                continue
            # 考虑从左上、上、左移动到当前位置的成本
            min_cost = min(
                cost_mat[i-1, j-1] if i > 0 and j > 0 else np.inf,
                cost_mat[i-1, j] if i > 0 else np.inf,
                cost_mat[i, j-1] if j > 0 else np.inf
            )
            cost_mat[i, j] = dst_mat[i, j] + min_cost
    return cost_mat

def backtrack(cost_mat, window_size):
    M, N = cost_mat.shape
    i, j = M-1, N-1
    path = [(i, j)]
    while i > 0 or j > 0:
        if i == 0:
            j -= 1
        elif j == 0:
            i -= 1
        else:
            # 只考虑在窗口范围内的三个方向
            go_direction = np.argmin([
                cost_mat[i-1, j-1] if i > 0 and j > 0 else np.inf,
                cost_mat[i-1, j] if i > 0 else np.inf,
                cost_mat[i, j-1] if j > 0 else np.inf
            ])
            if go_direction == 0:
                i -= 1
                j -= 1
            elif go_direction == 1:
                i -= 1
            else:
                j -= 1
        path.append((i, j))
    total_cost = np.sum([cost_mat[i, j] for i, j in path])
    return path[::-1], total_cost

def dtw(signal1, signal2, window_size=1, dst_criterion='abs'):
    cost_mat = dp(signal1, signal2, window_size, dst_criterion)
    path, total_cost = backtrack(cost_mat, window_size)
    return path, total_cost

def aggr_dtw(signal1, signal_list, window_size, dst_criterion):
    cost_list = []
    for signal2 in signal_list:
        path, total_cost = dtw(signal1, signal2, window_size, dst_criterion)
        cost_list.append(total_cost)
    aggr_dtw_val = np.mean(cost_list)
    return aggr_dtw_val

def cluster_train_data(train_data):
    train_data_dict = {}
    for arr in train_data:
        label = arr[0]
        ts = np.array(arr[1:]).astype(float)
        if label not in train_data_dict:
            train_data_dict[label] = []
        train_data_dict[label].append(ts)
    return train_data_dict

def predict(train_data, test_data, window_size, dst_criterion):
    """
        return prediction accuracy
    """
    start_time = time.time()
    train_data_dict = cluster_train_data(train_data)
    acc_num = 0
    
    for arr in test_data:
        start_time2 = time.time()
        label = arr[0]  # 真实标签
        test_X = np.array(arr[1:]).astype(float)
        
        # 初始化最小值和候选标签列表
        min_val = float('inf')
        pred_labels = []
        
        # 一次遍历找到具有最小距离的标签
        for train_label, train_X_list in train_data_dict.items():
            aggr_dtw_val = aggr_dtw(test_X, train_X_list, window_size, dst_criterion)
            
            if aggr_dtw_val < min_val:
                # 更新最小值并重置候选标签
                min_val = aggr_dtw_val
                pred_labels = [train_label]
            elif aggr_dtw_val == min_val:
                # 如果 aggr_dtw_val 等于当前最小值，添加到候选标签
                pred_labels.append(train_label)
        
        # 检查真实标签是否在 pred_labels 中
        if label in pred_labels:
            acc_num += 1

        print(f"Time elapsed for one prediction: {round(time.time() - start_time2, 2)}s")
    
    print(f"Time elapsed for all predictions: {round(time.time() - start_time, 2)}s")
    return acc_num / len(test_data)

if __name__ == '__main__':
    train = 'data/train_data_ts.tsv'
    test = 'data/test_data_ts.tsv'
    train_large = 'data_large/train_data.tsv'
    test_large = 'data_large/test_data.tsv'

    train_data = read_data(train)
    test_data = read_data(test)
    train_data_large = read_data(train_large)
    test_data_large = read_data(test_large)

    # plot_data(train_data)
    # plot_data(test_data)
    full_length = len(train_data[0])
    full_length_large = len(train_data_large[0])
    acc = predict(train_data, test_data, window_size=full_length, dst_criterion='abs')
    print(f"Accuracy: {acc}")