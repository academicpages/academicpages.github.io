import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from numba import njit
import time

def read_data(file):
    data = []
    with open(file, 'r') as f:
        for line in f:
            line = line.strip().split('\t')
            data.append(line)
    return data

def plot_data(data):
    unique_labels = list(set(arr[0] for arr in data))
    print(f"total labels: {len(unique_labels)}")
    colors = plt.cm.get_cmap('tab10', len(unique_labels))

    # Plot each time series with the corresponding color
    for arr in data:
        label = arr[0]
        ts = np.array(arr[1:]).astype(float)
        color = colors(unique_labels.index(label))
        plt.plot(ts, color=color)

    # plt.legend(unique_labels, loc='right')
    plt.show()


def dp(signal1, signal2, window_size):
    """
        2D Dynamic Programming Algorithm for DTW
        Input: 
        - signal1: 1D array, the sequence of signal 1
        - signal2: 1D array, the sequence of signal 2
        - window_size: int, the window size for constraint. For example, the i-th element in signal1 can only be matched with the j-th element in signal2 if j is in the range of [i-window_size, i+window_size]

        Output:
        - total_cost: float, the total cost of the optimal alignment, measured by abs distance
    """
    dst_mat = np.abs(signal1[:, np.newaxis] - signal2)

    M, N = len(signal1), len(signal2)
    cost_mat = np.full((M, N), np.inf)  # cost matrix
    window_size = max(window_size, abs(M - N))  # the window size shoule be at least abs(M-N)

    cost_mat[0, 0] = dst_mat[0, 0]  # initialization
    
    # filling the cost matrix by dynamic programming
    for i in range(M):
        for j in range(max(0, i - window_size), min(N, i + window_size + 1)):
            if i == 0 and j == 0:
                continue
            min_cost = min(
                cost_mat[i-1, j-1] if i > 0 and j > 0 else np.inf,  # upper left
                cost_mat[i-1, j] if i > 0 else np.inf,              # upper
                cost_mat[i, j-1] if j > 0 else np.inf               # left
            )
            cost_mat[i, j] = dst_mat[i, j] + min_cost
    return cost_mat[-1, -1]     # the total cost of the optimal alignment falls on the last element of the cost matrix

@njit
def dp2(signal1, signal2, window_size):
    """
        1D Dynamic Programming Algorithm for DTW. The idea is to use two rolling 1D arrays to replace the 2D matrix in the previous implementation. Lowering the space complexity from O(MN) to O(N)
        Input:
        - signal1: 1D array, the sequence of signal 1
        - signal2: 1D array, the sequence of signal 2
        - window_size: int, the window size for constraint. For example, the i-th element in signal1 can only be matched with the j-th element in signal2 if j is in the range of [i-window_size, i+window_size]

        Output:
        - total_cost: float, the total cost of the optimal alignment, measured by abs distance
    """
    M, N = len(signal1), len(signal2)
    window_size = max(window_size, abs(M - N))
    cost_prev = np.full(N, np.inf)  # cost vector for the previous row
    cost_curr = np.full(N, np.inf)  # cost vector for the current row
    
    # Initialize the first row
    for j in range(min(N, window_size + 1)):        # constrain initialization by truncating at window_size
        cost_prev[j] = abs(signal1[0] - signal2[j]) # initialize cost_prev[0]
        if j > 0:
            cost_prev[j] += cost_prev[j - 1]        # accumulate cost_prev[j] by adding cost_prev[j-1]
    
    for i in range(1, M):                           # iterate through the rest of the rows (1,...,M-1)
        imin = max(0, i - window_size)
        imax = min(N, i + window_size + 1)
        cost_curr = np.full(N, np.inf)
        for j in range(imin, imax):
            cost = abs(signal1[i] - signal2[j])
            if j == 0:
                min_cost = cost_prev[j]
            else:
                # cost_prev[j] -> up
                # cost_prev[j-1] -> upper left
                # cost_curr[j-1] -> left
                min_cost = min(cost_prev[j], cost_prev[j - 1], cost_curr[j - 1])
            cost_curr[j] = cost + min_cost
        cost_prev = cost_curr.copy()                # update cost_prev for the next iteration
    total_cost = cost_prev[N - 1]                   # the total cost of the optimal alignment falls on the last element of the last cost vector
    return total_cost

def dtw(signal1, signal2, window_size):
    """
        Wrapper function for the 1D Dynamic Programming Algorithm for DTW
        (Deprecated, used to return the optimal path and optimal total cost, now return the total cost only)
        Input:
        - signal1: 1D array, the sequence of signal 1
        - signal2: 1D array, the sequence of signal 2
        - window_size: int, the window size for constraint. For example, the i-th element in signal1 can only be matched with the j-th element in signal2 if j is in the range of [i-window_size, i+window_size]

        Output:
        - total_cost: float, the total cost of the optimal alignment, measured by abs distance
    """
    total_cost = dp2(signal1, signal2, window_size)
    return total_cost

def aggr_dtw(signal1, signal_list, window_size):
    """
        Aggregating (averaging) the alignment cost for a single signal against a list of signals
        Input:
        - signal1: 1D array, the sequence of signal 1
        - signal_list: list of 1D arrays, the list of signals to be compared with signal1
        - window_size: int, the window size for constraint. For example, the i-th element in signal1 can only be matched with the j-th element in signal2 if j is in the range of [i-window_size, i+window_size]

        Output:
        - aggr_dtw_val: float, the aggregated alignment cost for signal1 against the list of signals
    """
    cost_list = []
    for signal2 in signal_list:
        total_cost = dtw(signal1, signal2, window_size)
        cost_list.append(total_cost)
    aggr_dtw_val = np.mean(cost_list)
    return aggr_dtw_val

def cluster_train_data(train_data):
    """
        Clustering the training data by labels
        Input:
        - train_data: list of lists, each element within `train_data` is a list where the first element is the label and the rest are the time series data

        Output:
        - train_data_dict: dict, a dictionary where the keys are the labels and the values are the list of time series data corresponding to the labels
    """
    train_data_dict = {}
    for arr in train_data:
        label = arr[0]
        ts = np.array(arr[1:]).astype(float)
        if label not in train_data_dict:
            train_data_dict[label] = []
        train_data_dict[label].append(ts)
    return train_data_dict

# ------------ Parallel Computing ------------
# Use multiprocessing to parallelize the prediction process
# Establish training data and test data as global variables to be shared among processes, lowering the cost of data transfer

train = 'data/train_data_ts.tsv'
test = 'data/test_data_ts.tsv'
train_large = 'data_large/train_data.tsv'
test_large = 'data_large/test_data.tsv'

train_data = read_data(train)
test_data = read_data(test)
train_data_large = read_data(train_large)
test_data_large = read_data(test_large)

train_data_dict = cluster_train_data(train_data)
train_data_large_dict = cluster_train_data(train_data_large)


def predict_single(arr, window_size):
    """
        Predict the label of a single test data point
        Input:
        - arr: list, a list where the first element is the label and the rest are the time series data
        - window_size: int, the window size for constraint.

        Output:
        - is_correct: bool, whether the prediction is correct
    """
    label = arr[0]
    test_X = np.array(arr[1:]).astype(float)
    min_val = float('inf')
    pred_labels = []
    start_time = time.time()
    for train_label, train_X_list in train_data_dict.items():
        aggr_dtw_val = aggr_dtw(test_X, train_X_list, window_size)
        if aggr_dtw_val < min_val:
            min_val = aggr_dtw_val
            pred_labels = [train_label]
        elif aggr_dtw_val == min_val:
            pred_labels.append(train_label)
    
    is_correct = label in pred_labels
    print(f"Time elapsed for one prediction: {round(time.time() - start_time, 2)}s, pred: {pred_labels}, true: {label}")
    return is_correct


def predict_parallel(window_size):
    """
        Predict the labels of all test data points in parallel
        Input:
        - window_size: int, the window size for constraint.

        Output:
        - acc: float, the accuracy of the prediction
    """
    start_time = time.time()

    with ProcessPoolExecutor() as executor:
        results = list(executor.map(predict_single, test_data, [window_size] * len(test_data)))

    acc_num = sum(results)
    print(f"Time elapsed for all predictions: {round(time.time() - start_time, 2)}s")
    return acc_num / len(test_data)

def plot_best_window_size(max_length, patience=100):
    """
        Plot the accuracy of the prediction with different window sizes
        Input:
        - window_size_list: list, a list of window sizes to be tested
    """
    window_size_list = np.arange(1, max_length, 10)
    acc_list = []
    best_acc = 0
    count = 0
    for window_size in window_size_list:
        acc = predict_parallel(window_size)
        acc_list.append(acc)
        if acc > best_acc:
            best_acc = acc
            count = 0
        else:
            count += 1
        if count == patience:
            break
        print(f"Window Size: {window_size}, Accuracy: {acc}")
    plt.plot(window_size_list[:len(acc_list)], acc_list)
    plt.xlabel('Window Size')
    plt.ylabel('Accuracy')
    plt.title('Accuracy of Prediction with Different Window Sizes')
    plt.savefig('accuracy.png')


if __name__ == '__main__':
    # plot_data(train_data)
    # plot_data(test_data)
    full_length = len(train_data[0])-1
    full_length_large = len(train_data_large[0])-1
    # acc = predict_parallel(window_size=0.1*full_length_large)
    plot_best_window_size(full_length)